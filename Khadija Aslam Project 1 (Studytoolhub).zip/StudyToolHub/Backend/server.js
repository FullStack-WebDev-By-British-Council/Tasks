
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const userRoute = require("./routes/userRoute");
const contactRoute = require("./routes/contactRoute");
const signUpRoute = require("./routes/SignUpRoute");
const signInRoute = require("./routes/SignInRoute");

const app = express();
const port = 5500;

// Middleware
app.use(express.json());
app.use(cors());

// Routes
app.use(userRoute);
app.use(signUpRoute);
app.use(signInRoute);
app.use(contactRoute);

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/studytoolhub")
    .then(() => {
        console.log("MongoDB Connection Successful");
    })
    .catch((error) => {
        console.log("MongoDB Connection Error:", error.message);
    });

// Start Server
app.listen(port, () => {
    console.log(`Server Started on port ${port}`);
});
