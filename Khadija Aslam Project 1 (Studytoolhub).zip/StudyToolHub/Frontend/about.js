// Current Year

const year = document.getElementById("year");

year.innerText = new Date().getFullYear();


// Scroll Animation

const animatedItems = document.querySelectorAll(
    ".provide-card, .why-card, .who-content, .who-image, .goal-container"
);

const observer = new IntersectionObserver(function(entries) {

    entries.forEach(function(entry) {

        if (entry.isIntersecting) {

            entry.target.classList.add("show");

        }

    });

}, {
    threshold: 0.15
});


animatedItems.forEach(function(item) {

    item.classList.add("hidden");

    observer.observe(item);

});