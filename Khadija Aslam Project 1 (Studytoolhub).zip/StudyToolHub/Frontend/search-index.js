window.STUDY_SEARCH_ITEMS = [
  {
    "title": "Home",
    "url": "index.html",
    "category": "Page",
    "keywords": "home main page"
  },
  {
    "title": "Tools",
    "url": "tool.html",
    "category": "Page",
    "keywords": "tools calculators"
  },
  {
    "title": "Notes",
    "url": "notes.html",
    "category": "Page",
    "keywords": "study notes subjects"
  },
  {
    "title": "Blog",
    "url": "BLOG.HTML",
    "category": "Page",
    "keywords": "articles learning"
  },
  {
    "title": "About",
    "url": "about.html",
    "category": "Page",
    "keywords": "about us"
  },
  {
    "title": "Contact",
    "url": "contact.html",
    "category": "Page",
    "keywords": "contact message"
  },
  {
    "title": "Scientific Calculator",
    "url": "ScientificCalculator.html",
    "category": "Tool",
    "keywords": "scientific math calculator"
  },
  {
    "title": "Basic Calculator",
    "url": "basicCalculator.html",
    "category": "Tool",
    "keywords": "addition subtraction multiplication division"
  },
  {
    "title": "Percentage Calculator",
    "url": "PercentageCalculator.html",
    "category": "Tool",
    "keywords": "percentage percent"
  },
  {
    "title": "Average Calculator",
    "url": "average.html",
    "category": "Tool",
    "keywords": "mean average"
  },
  {
    "title": "Fraction Calculator",
    "url": "Fraction.html",
    "category": "Tool",
    "keywords": "fractions"
  },
  {
    "title": "Ratio Calculator",
    "url": "Ratio.html",
    "category": "Tool",
    "keywords": "ratio proportion"
  },
  {
    "title": "LCM Calculator",
    "url": "LCM.html",
    "category": "Tool",
    "keywords": "least common multiple"
  },
  {
    "title": "HCF Calculator",
    "url": "HCF.html",
    "category": "Tool",
    "keywords": "highest common factor gcd"
  },
  {
    "title": "Study Time Calculator",
    "url": "studytime.html",
    "category": "Tool",
    "keywords": "study schedule time"
  },
  {
    "title": "Attendance Calculator",
    "url": "attendence.html",
    "category": "Tool",
    "keywords": "attendance percentage"
  },
  {
    "title": "CGPA Calculator",
    "url": "CGPA.html",
    "category": "Tool",
    "keywords": "grade point average"
  },
  {
    "title": "Grade Calculator",
    "url": "marks.html",
    "category": "Tool",
    "keywords": "marks grades result"
  },
  {
    "title": "Binary to Decimal",
    "url": "binary to decimal.html",
    "category": "Tool",
    "keywords": "binary conversion"
  },
  {
    "title": "Decimal to Binary",
    "url": "decimaltobinary.html",
    "category": "Tool",
    "keywords": "binary conversion"
  },
  {
    "title": "Binary to Hexadecimal",
    "url": "binarytohexa.html",
    "category": "Tool",
    "keywords": "hexadecimal conversion"
  },
  {
    "title": "Decimal to Hexadecimal",
    "url": "decimaltohexa.html",
    "category": "Tool",
    "keywords": "hexadecimal conversion"
  },
  {
    "title": "Number System",
    "url": "math.html#modal1",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Factors & Multiples",
    "url": "math.html#modal2",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Fractions",
    "url": "math.html#modal3",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Decimals",
    "url": "math.html#modal4",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Ratio & Proportion",
    "url": "math.html#modal5",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Percentages",
    "url": "math.html#modal6",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Integers",
    "url": "math.html#modal7",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Exponents & Powers",
    "url": "math.html#modal8",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Algebraic Expressions",
    "url": "math.html#modal9",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Linear Equations",
    "url": "math.html#modal10",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Quadratic Equations",
    "url": "math.html#modal11",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Polynomials",
    "url": "math.html#modal12",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Factorization",
    "url": "math.html#modal13",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Sets",
    "url": "math.html#modal14",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Functions",
    "url": "math.html#modal15",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Sequences & Series",
    "url": "math.html#modal16",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Lines & Angles",
    "url": "math.html#modal17",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Triangles",
    "url": "math.html#modal18",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Quadrilaterals",
    "url": "math.html#modal19",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Polygons",
    "url": "math.html#modal20",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Circles",
    "url": "math.html#modal21",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Congruence & Similarity",
    "url": "math.html#modal22",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Perimeter & Area",
    "url": "math.html#modal23",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Surface Area & Volume",
    "url": "math.html#modal24",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Coordinate Geometry",
    "url": "math.html#modal25",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Trigonometric Ratios",
    "url": "math.html#modal26",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Trigonometric Identities",
    "url": "math.html#modal27",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Statistics",
    "url": "math.html#modal28",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Probability",
    "url": "math.html#modal29",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Matrices & Determinants",
    "url": "math.html#modal30",
    "category": "Mathematics Notes",
    "keywords": "Mathematics notes topic education study"
  },
  {
    "title": "Introduction to Science",
    "url": "science.html#modal1",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Matter",
    "url": "science.html#modal2",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "States of Matter",
    "url": "science.html#modal3",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Elements & Compounds",
    "url": "science.html#modal4",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Mixtures",
    "url": "science.html#modal5",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Atoms",
    "url": "science.html#modal6",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Molecules",
    "url": "science.html#modal7",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Physical & Chemical Changes",
    "url": "science.html#modal8",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Force",
    "url": "science.html#modal9",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Motion",
    "url": "science.html#modal10",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Work & Energy",
    "url": "science.html#modal11",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Heat & Temperature",
    "url": "science.html#modal12",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Light",
    "url": "science.html#modal13",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Sound",
    "url": "science.html#modal14",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Electricity",
    "url": "science.html#modal15",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Magnetism",
    "url": "science.html#modal16",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Cells",
    "url": "science.html#modal17",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Tissues",
    "url": "science.html#modal18",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Human Body",
    "url": "science.html#modal19",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Digestive System",
    "url": "science.html#modal20",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Respiratory System",
    "url": "science.html#modal21",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Circulatory System",
    "url": "science.html#modal22",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Photosynthesis",
    "url": "science.html#modal23",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Reproduction in Plants",
    "url": "science.html#modal24",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Ecosystem",
    "url": "science.html#modal25",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Food Chain & Food Web",
    "url": "science.html#modal26",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Water Cycle",
    "url": "science.html#modal27",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Solar System",
    "url": "science.html#modal28",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Environment & Pollution",
    "url": "science.html#modal29",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Natural Resources",
    "url": "science.html#modal30",
    "category": "Science Notes",
    "keywords": "Science notes topic education study"
  },
  {
    "title": "Parts of Speech",
    "url": "english.html#modal1",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Nouns",
    "url": "english.html#modal2",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Pronouns",
    "url": "english.html#modal3",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Verbs",
    "url": "english.html#modal4",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Adjectives",
    "url": "english.html#modal5",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Adverbs",
    "url": "english.html#modal6",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Prepositions",
    "url": "english.html#modal7",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Conjunctions",
    "url": "english.html#modal8",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Interjections",
    "url": "english.html#modal9",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Articles",
    "url": "english.html#modal10",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Tenses",
    "url": "english.html#modal11",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Present Tense",
    "url": "english.html#modal12",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Past Tense",
    "url": "english.html#modal13",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Future Tense",
    "url": "english.html#modal14",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Sentence Structure",
    "url": "english.html#modal15",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Types of Sentences",
    "url": "english.html#modal16",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Active & Passive Voice",
    "url": "english.html#modal17",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Direct & Indirect Speech",
    "url": "english.html#modal18",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Conditional Sentences",
    "url": "english.html#modal19",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Question Formation",
    "url": "english.html#modal20",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Negative Sentences",
    "url": "english.html#modal21",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Vocabulary",
    "url": "english.html#modal22",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Synonyms",
    "url": "english.html#modal23",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Antonyms",
    "url": "english.html#modal24",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Paragraph Writing",
    "url": "english.html#modal25",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Email Writing",
    "url": "english.html#modal26",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Essay Writing",
    "url": "english.html#modal27",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Speaking Skills",
    "url": "english.html#modal28",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Listening Skills",
    "url": "english.html#modal29",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Common Grammar Mistakes",
    "url": "english.html#modal30",
    "category": "English Notes",
    "keywords": "English notes topic education study"
  },
  {
    "title": "Introduction to Computers",
    "url": "computer.html#modal1",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Hardware",
    "url": "computer.html#modal2",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Software",
    "url": "computer.html#modal3",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "CPU",
    "url": "computer.html#modal4",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Memory",
    "url": "computer.html#modal5",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Storage Devices",
    "url": "computer.html#modal6",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Operating Systems",
    "url": "computer.html#modal7",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Programming Languages",
    "url": "computer.html#modal8",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Algorithms",
    "url": "computer.html#modal9",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Flowcharts",
    "url": "computer.html#modal10",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Variables & Data Types",
    "url": "computer.html#modal11",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Functions",
    "url": "computer.html#modal12",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Conditions",
    "url": "computer.html#modal13",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Loops",
    "url": "computer.html#modal14",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "JavaScript",
    "url": "computer.html#modal15",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "HTML",
    "url": "computer.html#modal16",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "CSS",
    "url": "computer.html#modal17",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Internet",
    "url": "computer.html#modal18",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Web Browsers",
    "url": "computer.html#modal19",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Client & Server",
    "url": "computer.html#modal20",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Computer Networks",
    "url": "computer.html#modal21",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "IP Address",
    "url": "computer.html#modal22",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Databases",
    "url": "computer.html#modal23",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "SQL",
    "url": "computer.html#modal24",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Cyber Security",
    "url": "computer.html#modal25",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Passwords & Authentication",
    "url": "computer.html#modal26",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Cloud Computing",
    "url": "computer.html#modal27",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Artificial Intelligence",
    "url": "computer.html#modal28",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Git & GitHub",
    "url": "computer.html#modal29",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  },
  {
    "title": "Web Development",
    "url": "computer.html#modal30",
    "category": "Computer Science Notes",
    "keywords": "Computer Science notes topic education study"
  }
];
