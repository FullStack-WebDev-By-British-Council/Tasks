
const FAVORITES_KEY = "studyToolHubFavorites";
const HISTORY_KEY = "studyToolHubHistory";

const searchInput = document.getElementById("notesSearch");
const cards = document.querySelectorAll(".notes-card");
const noResult = document.getElementById("noResult");

// LocalStorage se list read karna
function readList(key) {
    try {
        const data = JSON.parse(localStorage.getItem(key));
        return Array.isArray(data) ? data : [];
    } catch (error) {
        return [];
    }
}

// LocalStorage mein list save karna
function saveList(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

// Saved favorites ke hearts update karna
function updateFavoriteButtons() {
    const favorites = readList(FAVORITES_KEY);

    document.querySelectorAll(".favorite-btn").forEach(button => {
        const saved = favorites.some(
            item => item.id === button.dataset.id
        );

        const icon = button.querySelector("i");

        button.classList.toggle("is-favorite", saved);
        button.setAttribute("aria-pressed", String(saved));

        button.setAttribute(
            "aria-label",
            saved
                ? `Remove ${button.dataset.title} from favorites`
                : `Add ${button.dataset.title} to favorites`
        );

        if (icon) {
            icon.className = saved
                ? "ri-heart-fill"
                : "ri-heart-line";
        }
    });
}

// Heart click: favorite add ya remove
document.querySelectorAll(".favorite-btn").forEach(button => {
    button.addEventListener("click", function () {
        const favorites = readList(FAVORITES_KEY);
        const itemId = this.dataset.id;

        const alreadySaved = favorites.some(
            item => item.id === itemId
        );

        let updatedFavorites;

        if (alreadySaved) {
            // Favorite se remove karna
            updatedFavorites = favorites.filter(
                item => item.id !== itemId
            );
        } else {
            // Favorite mein add karna
            const favoriteItem = {
                id: itemId,
                title: this.dataset.title,
                type: this.dataset.type,
                url: this.dataset.url,
                icon: this.dataset.icon
            };

            updatedFavorites = [...favorites, favoriteItem];
        }

        saveList(FAVORITES_KEY, updatedFavorites);

        updateFavoriteButtons();
    });
});

// Recently Viewed mein subject save karna
document.querySelectorAll(".notes-btn").forEach(link => {
    link.addEventListener("click", function () {
        const card = this.closest(".notes-card");

        if (!card) return;

        const titleElement = card.querySelector(".card-content h2");
        const iconElement = card.querySelector(".card-icon i");

        const title = titleElement
            ? titleElement.textContent.trim()
            : "Study Notes";

        const subject = title
            .toLowerCase()
            .replace(/\s+/g, "-");

        const historyItem = {
            id: "notes-" + subject,
            title: title + " Notes",
            type: "Note",
            url: this.href,
            icon: iconElement
                ? iconElement.className
                : "ri-book-open-line",
            viewedAt: new Date().toISOString()
        };

        let history = readList(HISTORY_KEY);

        // Duplicate entry remove karna
        history = history.filter(
            item => item.id !== historyItem.id
        );

        // Latest viewed subject sab se upar
        history.unshift(historyItem);

        // Maximum 20 items save karna
        history = history.slice(0, 20);

        saveList(HISTORY_KEY, history);
    });
});

// Subject search
if (searchInput && noResult) {
    searchInput.addEventListener("input", function () {
        const searchValue = this.value.toLowerCase().trim();
        let found = false;

        cards.forEach(card => {
            const cardText = card.textContent.toLowerCase();
            const matches = cardText.includes(searchValue);

            // Existing grid layout preserve karna
            card.style.display = matches ? "" : "none";

            if (matches) {
                found = true;
            }
        });

        noResult.style.display = found ? "none" : "block";
    });
}

// Page load par saved hearts dikhana
updateFavoriteButtons();

/* =====================================
   SEARCH ALL TOPICS
===================================== */

const topicSearchResults = document.getElementById("topicSearchResults");

const allNoteTopics = [
    // SCIENCE
    { title: "Introduction to Science", subject: "Science", page: "science.html", modal: 1 },
    { title: "Matter", subject: "Science", page: "science.html", modal: 2 },
    { title: "States of Matter", subject: "Science", page: "science.html", modal: 3 },
    { title: "Elements & Compounds", subject: "Science", page: "science.html", modal: 4 },
    { title: "Mixtures", subject: "Science", page: "science.html", modal: 5 },
    { title: "Atoms", subject: "Science", page: "science.html", modal: 6 },
    { title: "Molecules", subject: "Science", page: "science.html", modal: 7 },
    { title: "Physical & Chemical Changes", subject: "Science", page: "science.html", modal: 8 },
    { title: "Force", subject: "Science", page: "science.html", modal: 9 },
    { title: "Motion", subject: "Science", page: "science.html", modal: 10 },
    { title: "Work & Energy", subject: "Science", page: "science.html", modal: 11 },
    { title: "Heat & Temperature", subject: "Science", page: "science.html", modal: 12 },
    { title: "Light", subject: "Science", page: "science.html", modal: 13 },
    { title: "Sound", subject: "Science", page: "science.html", modal: 14 },
    { title: "Electricity", subject: "Science", page: "science.html", modal: 15 },
    { title: "Magnetism", subject: "Science", page: "science.html", modal: 16 },
    { title: "Cells", subject: "Science", page: "science.html", modal: 17 },
    { title: "Tissues", subject: "Science", page: "science.html", modal: 18 },
    { title: "Human Body", subject: "Science", page: "science.html", modal: 19 },
    { title: "Digestive System", subject: "Science", page: "science.html", modal: 20 },
    { title: "Respiratory System", subject: "Science", page: "science.html", modal: 21 },
    { title: "Circulatory System", subject: "Science", page: "science.html", modal: 22 },
    { title: "Photosynthesis", subject: "Science", page: "science.html", modal: 23 },
    { title: "Reproduction in Plants", subject: "Science", page: "science.html", modal: 24 },
    { title: "Ecosystem", subject: "Science", page: "science.html", modal: 25 },
    { title: "Food Chain & Food Web", subject: "Science", page: "science.html", modal: 26 },
    { title: "Water Cycle", subject: "Science", page: "science.html", modal: 27 },
    { title: "Solar System", subject: "Science", page: "science.html", modal: 28 },
    { title: "Environment & Pollution", subject: "Science", page: "science.html", modal: 29 },
    { title: "Natural Resources", subject: "Science", page: "science.html", modal: 30 },

    // MATHEMATICS
    { title: "Number System", subject: "Mathematics", page: "math.html", modal: 1 },
    { title: "Factors & Multiples", subject: "Mathematics", page: "math.html", modal: 2 },
    { title: "Fractions", subject: "Mathematics", page: "math.html", modal: 3 },
    { title: "Decimals", subject: "Mathematics", page: "math.html", modal: 4 },
    { title: "Ratio & Proportion", subject: "Mathematics", page: "math.html", modal: 5 },
    { title: "Percentages", subject: "Mathematics", page: "math.html", modal: 6 },
    { title: "Integers", subject: "Mathematics", page: "math.html", modal: 7 },
    { title: "Exponents & Powers", subject: "Mathematics", page: "math.html", modal: 8 },
    { title: "Algebraic Expressions", subject: "Mathematics", page: "math.html", modal: 9 },
    { title: "Linear Equations", subject: "Mathematics", page: "math.html", modal: 10 },
    { title: "Quadratic Equations", subject: "Mathematics", page: "math.html", modal: 11 },
    { title: "Polynomials", subject: "Mathematics", page: "math.html", modal: 12 },
    { title: "Factorization", subject: "Mathematics", page: "math.html", modal: 13 },
    { title: "Sets", subject: "Mathematics", page: "math.html", modal: 14 },
    { title: "Functions", subject: "Mathematics", page: "math.html", modal: 15 },
    { title: "Sequences & Series", subject: "Mathematics", page: "math.html", modal: 16 },
    { title: "Lines & Angles", subject: "Mathematics", page: "math.html", modal: 17 },
    { title: "Triangles", subject: "Mathematics", page: "math.html", modal: 18 },
    { title: "Quadrilaterals", subject: "Mathematics", page: "math.html", modal: 19 },
    { title: "Polygons", subject: "Mathematics", page: "math.html", modal: 20 },
    { title: "Circles", subject: "Mathematics", page: "math.html", modal: 21 },
    { title: "Congruence & Similarity", subject: "Mathematics", page: "math.html", modal: 22 },
    { title: "Perimeter & Area", subject: "Mathematics", page: "math.html", modal: 23 },
    { title: "Surface Area & Volume", subject: "Mathematics", page: "math.html", modal: 24 },
    { title: "Coordinate Geometry", subject: "Mathematics", page: "math.html", modal: 25 },
    { title: "Trigonometric Ratios", subject: "Mathematics", page: "math.html", modal: 26 },
    { title: "Trigonometric Identities", subject: "Mathematics", page: "math.html", modal: 27 },
    { title: "Statistics", subject: "Mathematics", page: "math.html", modal: 28 },
    { title: "Probability", subject: "Mathematics", page: "math.html", modal: 29 },
    { title: "Matrices & Determinants", subject: "Mathematics", page: "math.html", modal: 30 },

    // ENGLISH
    { title: "Parts of Speech", subject: "English", page: "english.html", modal: 1 },
    { title: "Nouns", subject: "English", page: "english.html", modal: 2 },
    { title: "Pronouns", subject: "English", page: "english.html", modal: 3 },
    { title: "Verbs", subject: "English", page: "english.html", modal: 4 },
    { title: "Adjectives", subject: "English", page: "english.html", modal: 5 },
    { title: "Adverbs", subject: "English", page: "english.html", modal: 6 },
    { title: "Prepositions", subject: "English", page: "english.html", modal: 7 },
    { title: "Conjunctions", subject: "English", page: "english.html", modal: 8 },
    { title: "Interjections", subject: "English", page: "english.html", modal: 9 },
    { title: "Articles", subject: "English", page: "english.html", modal: 10 },
    { title: "Tenses", subject: "English", page: "english.html", modal: 11 },
    { title: "Present Tense", subject: "English", page: "english.html", modal: 12 },
    { title: "Past Tense", subject: "English", page: "english.html", modal: 13 },
    { title: "Future Tense", subject: "English", page: "english.html", modal: 14 },
    { title: "Sentence Structure", subject: "English", page: "english.html", modal: 15 },
    { title: "Types of Sentences", subject: "English", page: "english.html", modal: 16 },
    { title: "Active & Passive Voice", subject: "English", page: "english.html", modal: 17 },
    { title: "Direct & Indirect Speech", subject: "English", page: "english.html", modal: 18 },
    { title: "Conditional Sentences", subject: "English", page: "english.html", modal: 19 },
    { title: "Question Formation", subject: "English", page: "english.html", modal: 20 },
    { title: "Negative Sentences", subject: "English", page: "english.html", modal: 21 },
    { title: "Vocabulary", subject: "English", page: "english.html", modal: 22 },
    { title: "Synonyms", subject: "English", page: "english.html", modal: 23 },
    { title: "Antonyms", subject: "English", page: "english.html", modal: 24 },
    { title: "Paragraph Writing", subject: "English", page: "english.html", modal: 25 },
    { title: "Email Writing", subject: "English", page: "english.html", modal: 26 },
    { title: "Essay Writing", subject: "English", page: "english.html", modal: 27 },
    { title: "Speaking Skills", subject: "English", page: "english.html", modal: 28 },
    { title: "Listening Skills", subject: "English", page: "english.html", modal: 29 },
    { title: "Common Grammar Mistakes", subject: "English", page: "english.html", modal: 30 },

    // COMPUTER SCIENCE
    { title: "Introduction to Computers", subject: "Computer Science", page: "computer.html", modal: 1 },
    { title: "Hardware", subject: "Computer Science", page: "computer.html", modal: 2 },
    { title: "Software", subject: "Computer Science", page: "computer.html", modal: 3 },
    { title: "CPU", subject: "Computer Science", page: "computer.html", modal: 4 },
    { title: "Memory", subject: "Computer Science", page: "computer.html", modal: 5 },
    { title: "Storage Devices", subject: "Computer Science", page: "computer.html", modal: 6 },
    { title: "Operating Systems", subject: "Computer Science", page: "computer.html", modal: 7 },
    { title: "Programming Languages", subject: "Computer Science", page: "computer.html", modal: 8 },
    { title: "Algorithms", subject: "Computer Science", page: "computer.html", modal: 9 },
    { title: "Flowcharts", subject: "Computer Science", page: "computer.html", modal: 10 },
    { title: "Variables & Data Types", subject: "Computer Science", page: "computer.html", modal: 11 },
    { title: "Functions", subject: "Computer Science", page: "computer.html", modal: 12 },
    { title: "Conditions", subject: "Computer Science", page: "computer.html", modal: 13 },
    { title: "Loops", subject: "Computer Science", page: "computer.html", modal: 14 },
    { title: "JavaScript", subject: "Computer Science", page: "computer.html", modal: 15 },
    { title: "HTML", subject: "Computer Science", page: "computer.html", modal: 16 },
    { title: "CSS", subject: "Computer Science", page: "computer.html", modal: 17 },
    { title: "Internet", subject: "Computer Science", page: "computer.html", modal: 18 },
    { title: "Web Browsers", subject: "Computer Science", page: "computer.html", modal: 19 },
    { title: "Client & Server", subject: "Computer Science", page: "computer.html", modal: 20 },
    { title: "Computer Networks", subject: "Computer Science", page: "computer.html", modal: 21 },
    { title: "IP Address", subject: "Computer Science", page: "computer.html", modal: 22 },
    { title: "Databases", subject: "Computer Science", page: "computer.html", modal: 23 },
    { title: "SQL", subject: "Computer Science", page: "computer.html", modal: 24 },
    { title: "Cyber Security", subject: "Computer Science", page: "computer.html", modal: 25 },
    { title: "Passwords & Authentication", subject: "Computer Science", page: "computer.html", modal: 26 },
    { title: "Cloud Computing", subject: "Computer Science", page: "computer.html", modal: 27 },
    { title: "Artificial Intelligence", subject: "Computer Science", page: "computer.html", modal: 28 },
    { title: "Git & GitHub", subject: "Computer Science", page: "computer.html", modal: 29 },
    { title: "Web Development", subject: "Computer Science", page: "computer.html", modal: 30 }
];


/* SEARCH RESULTS CONTAINER */

if (searchInput && topicSearchResults) {
    searchInput.addEventListener("input", function () {
        const value = this.value.trim().toLowerCase();

        topicSearchResults.innerHTML = "";

        if (!value) {
            topicSearchResults.style.display = "none";
            return;
        }

        const matches = allNoteTopics.filter(topic =>
            topic.title.toLowerCase().includes(value) ||
            topic.subject.toLowerCase().includes(value)
        );

        if (matches.length === 0) {
            topicSearchResults.innerHTML =
                "<p class='topic-no-result'>No topics found.</p>";
            topicSearchResults.style.display = "block";
            return;
        }

        matches.forEach(topic => {
            const link = document.createElement("a");

            link.className = "topic-search-result";
            link.href = `${topic.page}#modal${topic.modal}`;

            const title = document.createElement("strong");
            title.textContent = topic.title;

            const subject = document.createElement("span");
            subject.textContent = topic.subject;

            link.append(title, subject);
            topicSearchResults.appendChild(link);
        });

        topicSearchResults.style.display = "block";
    });
}
