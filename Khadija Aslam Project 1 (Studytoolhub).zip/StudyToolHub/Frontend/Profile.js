
const FAVORITES_KEY = "studyToolHubFavorites";
const HISTORY_KEY = "studyToolHubHistory";

const profileName = document.getElementById("profileName");
const profileEmail = document.getElementById("profileEmail");

const favoritesList = document.getElementById("favoritesList");
const historyList = document.getElementById("historyList");

const favoritesEmpty = document.getElementById("favoritesEmpty");
const historyEmpty = document.getElementById("historyEmpty");

const favoritesCount = document.getElementById("favoritesCount");
const historyCount = document.getElementById("historyCount");

const logoutBtn = document.getElementById("logoutBtn");
const clearHistoryBtn = document.getElementById("clearHistoryBtn");

// Login user
const loggedInUser = sessionStorage.getItem("loggedInUser");

if (!loggedInUser) {
    window.location.href = "signin.html";
} else {
    try {
        const user = JSON.parse(loggedInUser);

        profileName.textContent =
            user.name || user.fullName || user.username || "User";

        profileEmail.textContent = user.email || "";
    } catch (error) {
        sessionStorage.removeItem("loggedInUser");
        window.location.href = "signin.html";
    }
}

// Read saved data
function readList(key) {
    try {
        const data = JSON.parse(localStorage.getItem(key));
        return Array.isArray(data) ? data : [];
    } catch (error) {
        return [];
    }
}

// Safely create text elements
function createTextElement(tag, className, text) {
    const element = document.createElement(tag);
    element.className = className;
    element.textContent = text || "";
    return element;
}

// Create a favorite/history card
function createActivityCard(item, isFavorite = false) {
    const card = document.createElement("article");
    card.className = "activity-card";

    const iconBox = document.createElement("div");
    iconBox.className = "activity-icon";

    const icon = document.createElement("i");
    icon.className = item.icon || "ri-book-open-line";
    iconBox.appendChild(icon);

    const details = document.createElement("div");
    details.className = "activity-details";

    const title = createTextElement(
        "h3",
        "",
        item.title || item.name || "Untitled"
    );

    const type = createTextElement(
        "p",
        "",
        item.type || "Learning Resource"
    );

    details.append(title, type);

    if (item.url) {
        const link = document.createElement("a");
        link.className = "activity-link";
        link.href = item.url;
        link.appendChild(title);

        details.insertBefore(link, type);
    }

    card.append(iconBox, details);

    if (isFavorite) {
        const removeBtn = document.createElement("button");
        removeBtn.type = "button";
        removeBtn.className = "remove-favorite";
        removeBtn.innerHTML = '<i class="ri-delete-bin-line"></i>';
        removeBtn.title = "Remove from Favorites";
        removeBtn.setAttribute("aria-label", "Remove from Favorites");

        removeBtn.addEventListener("click", () => {
            const favorites = readList(FAVORITES_KEY).filter(
                favorite => favorite.id !== item.id
            );

            localStorage.setItem(
                FAVORITES_KEY,
                JSON.stringify(favorites)
            );

            renderProfile();
        });

        card.appendChild(removeBtn);
    }

    return card;
}

// Render favorites and history
function renderProfile() {
    const favorites = readList(FAVORITES_KEY);
    const history = readList(HISTORY_KEY);

    favoritesCount.textContent = favorites.length;
    historyCount.textContent = history.length;

    favoritesList.replaceChildren();
    historyList.replaceChildren();

    favoritesEmpty.style.display =
        favorites.length === 0 ? "block" : "none";

    historyEmpty.style.display =
        history.length === 0 ? "block" : "none";

    favorites.forEach(item => {
        favoritesList.appendChild(createActivityCard(item, true));
    });

    history.forEach(item => {
        historyList.appendChild(createActivityCard(item));
    });

    clearHistoryBtn.style.display =
        history.length === 0 ? "none" : "inline-block";
}

// Clear recently viewed
clearHistoryBtn.addEventListener("click", () => {
    const confirmClear = confirm(
        "Are you sure you want to clear your recent activity?"
    );

    if (confirmClear) {
        localStorage.removeItem(HISTORY_KEY);
        renderProfile();
    }
});

// Logout
logoutBtn.addEventListener("click", () => {
    sessionStorage.removeItem("loggedInUser");
    window.location.href = "index.html";
});

// Sidebar active link
document.querySelectorAll(".nav-link[href^='#']").forEach(link => {
    link.addEventListener("click", () => {
        document.querySelectorAll(".nav-link").forEach(navLink => {
            navLink.classList.remove("active");
        });

        link.classList.add("active");
    });
});

// Initial display
renderProfile();
