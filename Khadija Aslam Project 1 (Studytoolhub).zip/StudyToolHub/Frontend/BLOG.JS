const blogs = {

    calculator: {

        tag: "MATHEMATICAL TOOLS",

        title: "Calculator Guide",

        icon: "ri-calculator-line",

        text: `
            <p>
                Calculators are one of the most useful mathematical
                tools for students. They help perform calculations
                quickly and reduce the time needed to solve numerical
                problems.
            </p>

            <p>
                A basic calculator can be used for addition,
                subtraction, multiplication and division. A scientific
                calculator can also be used for more advanced operations
                such as powers, roots, trigonometric calculations and
                other mathematical functions.
            </p>

            <p>
                Students can use calculators while practicing questions,
                checking answers and working with large or complicated
                calculations. However, understanding the mathematical
                method is still important because the calculator should
                be used as a learning tool rather than simply replacing
                the calculation process.
            </p>

            <p>
                StudentToolsHub provides simple calculators so students
                can perform common calculations easily in one place.
            </p>
        `
    },


    percentage: {

        tag: "MATHEMATICAL TOOLS",

        title: "Percentage & Average Guide",

        icon: "ri-percent-line",

        text: `
            <p>
                Percentage is used to represent a value as a part of
                100. Students commonly use percentages when calculating
                marks, exam results, discounts and academic performance.
            </p>

            <p>
                The basic percentage formula is:
                Percentage = (Part ÷ Total) × 100.
            </p>

            <p>
                For example, if a student gets 80 marks out of 100,
                the percentage is 80%. If the total marks are different,
                the same formula can be used to find the percentage.
            </p>

            <p>
                Average is another important mathematical concept.
                To find an average, add all the values and divide the
                result by the number of values.
            </p>

            <p>
                These tools are especially useful for students who want
                to quickly check their marks, results and calculations.
            </p>
        `
    },


    grade: {

        tag: "MATHEMATICAL TOOLS",

        title: "Grade & Attendance Guide",

        icon: "ri-award-line",

        text: `
            <p>
                Grade and attendance are important parts of student
                academic performance. A grade usually represents how
                well a student performed in an examination or course.
            </p>

            <p>
                A grade calculator can help students understand their
                expected grade from their marks or percentage. The
                exact grade boundaries can be different depending on
                the institution or grading system.
            </p>

            <p>
                Attendance percentage tells students how many classes
                they attended compared with the total number of classes.
                The basic formula is:
                Attendance = (Classes Attended ÷ Total Classes) × 100.
            </p>

            <p>
                These calculators make it easier to check academic
                progress without doing repeated calculations manually.
            </p>
        `
    },


    binary: {

        tag: "NUMBER SYSTEM",

        title: "Binary Number Guide",

        icon: "ri-code-box-line",

        text: `
            <p>
                Binary is a number system that uses only two digits:
                0 and 1. It is one of the most important concepts
                in computer science.
            </p>

            <p>
                Computers use binary because digital electronic systems
                work with two basic states. These states can be
                represented using 0 and 1.
            </p>

            <p>
                For example, the decimal number 5 can be represented
                as 101 in binary. Learning these conversions helps
                students understand how computers represent information.
            </p>

            <p>
                Binary is also connected with programming, digital
                electronics, computer memory and data representation.
                That is why number-system tools are useful for
                Computer Science students.
            </p>
        `
    },


    decimal: {

        tag: "NUMBER SYSTEM",

        title: "Decimal Number Guide",

        icon: "ri-hashtag",

        text: `
            <p>
                Decimal is the number system that we use in everyday
                life. It is a base-10 number system and contains
                ten digits from 0 to 9.
            </p>

            <p>
                Each position in a decimal number represents a power
                of 10. For example, in the number 245, the digits
                represent hundreds, tens and ones.
            </p>

            <p>
                Decimal numbers can be converted into other number
                systems such as binary and hexadecimal. These
                conversions are commonly studied in Computer Science.
            </p>

            <p>
                Understanding the decimal system first makes it much
                easier to understand other number systems and their
                conversions.
            </p>
        `
    },


    hexadecimal: {

        tag: "NUMBER SYSTEM",

        title: "Hexadecimal Guide",

        icon: "ri-code-s-slash-line",

        text: `
            <p>
                Hexadecimal is a base-16 number system. It uses the
                digits 0 to 9 and the letters A, B, C, D, E and F.
            </p>

            <p>
                The letters represent values from 10 to 15. For example,
                A represents 10 and F represents 15.
            </p>

            <p>
                Hexadecimal is commonly used in computer science because
                it provides a shorter and easier way to represent large
                binary values.
            </p>

            <p>
                One hexadecimal digit represents four binary digits.
                This relationship makes hexadecimal useful when
                studying binary conversions, programming and digital
                systems.
            </p>
        `
    },


    mathematics: {

        tag: "SUBJECT GUIDE",

        title: "Mathematics Guide",

        icon: "ri-calculator-line",

        text: `
            <p>
                Mathematics helps students develop logical thinking,
                problem-solving skills and the ability to work with
                numbers, formulas and patterns.
            </p>

            <p>
                Important areas of mathematics include arithmetic,
                algebra, geometry, percentages, averages, equations
                and many other concepts.
            </p>

            <p>
                StudentToolsHub provides mathematical tools that can
                help students practice calculations and check their
                answers quickly.
            </p>

            <p>
                Detailed topic-wise mathematics notes can be added
                later in the Notes section. The Blog section will
                mainly provide guides and helpful explanations.
            </p>
        `
    },


    computer: {

        tag: "SUBJECT GUIDE",

        title: "Computer Science Guide",

        icon: "ri-computer-line",

        text: `
            <p>
                Computer Science is the study of computers, software,
                programming, data and digital systems. It helps students
                understand how technology works.
            </p>

            <p>
                Important Computer Science topics include programming,
                algorithms, number systems, databases, computer networks
                and web development.
            </p>

            <p>
                Number system tools such as Binary, Decimal and
                Hexadecimal converters can help students practice
                important Computer Science calculations.
            </p>

            <p>
                More detailed topic-wise notes can be provided in the
                Notes section as the StudentToolsHub content grows.
            </p>
        `
    },


    science: {

        tag: "SUBJECT GUIDE",

        title: "Science Guide",

        icon: "ri-flask-line",

        text: `
            <p>
                Science helps students understand the natural world
                through observation, experiments and logical thinking.
            </p>

            <p>
                Science can include subjects and areas such as physics,
                chemistry, biology, environment and everyday scientific
                concepts.
            </p>

            <p>
                Our Science guides are designed to explain concepts
                in simple language so students can understand and
                revise important ideas more easily.
            </p>

            <p>
                Detailed chapter-wise Science notes can later be added
                to the Notes section.
            </p>
        `
    },


    english: {

        tag: "SUBJECT GUIDE",

        title: "English Guide",

        icon: "ri-book-open-line",

        text: `
            <p>
                English is an important subject for education,
                communication and professional life. Improving English
                can help students in both academic and everyday situations.
            </p>

            <p>
                Important areas include grammar, vocabulary, sentence
                structure, reading, writing, speaking and communication.
            </p>

            <p>
                Students can use our English guides to understand basic
                concepts and improve their language skills step by step.
            </p>

            <p>
                More detailed grammar topics, vocabulary lists and
                chapter-wise material can be added later in the
                Notes section.
            </p>
        `
    }

};


const buttons = document.querySelectorAll(".read-more");

const blogDetail = document.getElementById("blogDetail");

const closeBlog = document.getElementById("closeBlog");

const detailIcon = document.getElementById("detailIcon");

const detailTag = document.getElementById("detailTag");

const detailTitle = document.getElementById("detailTitle");

const detailText = document.getElementById("detailText");


buttons.forEach(function(button) {

    button.addEventListener("click", function() {

        const blogName = button.dataset.blog;

        const blog = blogs[blogName];

        detailIcon.innerHTML =
            `<i class="${blog.icon}"></i>`;

        detailTag.innerText = blog.tag;

        detailTitle.innerText = blog.title;

        detailText.innerHTML = blog.text;

        blogDetail.classList.add("show");

        blogDetail.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

    });

});


closeBlog.addEventListener("click", function() {

    blogDetail.classList.remove("show");

});


/* Mobile Navbar */

const menuBtn = document.getElementById("menuBtn");

const navLinks = document.getElementById("navLinks");


menuBtn.addEventListener("click", function() {

    navLinks.classList.toggle("show");

});