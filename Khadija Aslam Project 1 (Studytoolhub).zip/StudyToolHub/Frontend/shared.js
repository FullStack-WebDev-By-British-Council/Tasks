(function(){
  const $ = (s, root=document) => root.querySelector(s);
  const trigger = $('#sthProfileTrigger');
  const menu = $('#sthProfileMenu');
  const nameEl = $('#sthProfileName');
  const wrap = $('#sthProfileWrap');
  const navLinks = $('.sth-nav-links');
  const menuToggle = $('.sth-menu-toggle');
  function getUser(){ try { return JSON.parse(sessionStorage.getItem('loggedInUser') || 'null'); } catch(e){ return null; } }
  function updateAccount(){
    if(!trigger || !menu || !nameEl) return;
    const user=getUser();
    const name=user && (user.name || user.fullName || user.email) ? (user.name || user.fullName || user.email) : '';
    nameEl.textContent=name || 'Sign In';
    menu.innerHTML='';
    const addLink=(href,label,icon)=>{ const a=document.createElement('a');a.href=href;a.innerHTML='<i class="'+icon+'"></i><span></span>';a.querySelector('span').textContent=label;menu.appendChild(a); };
    if(user){
      addLink('Profile.html','My Profile','ri-user-line');
      addLink('Profile.html#favorites','My Favorites','ri-heart-line');
      addLink('Profile.html#history','Recently Viewed','ri-history-line');
      const logout=document.createElement('button');logout.type='button';logout.innerHTML='<i class="ri-logout-box-r-line"></i><span>Sign Out</span>';
      logout.addEventListener('click',()=>{sessionStorage.removeItem('loggedInUser');window.location.href='index.html';});menu.appendChild(logout);
    } else {
      addLink('signin.html','Sign In','ri-login-box-line');
      addLink('signup.html','Create Account','ri-user-add-line');
    }
  }
  if(trigger && menu){
    updateAccount();
    trigger.addEventListener('click',()=>{const open=trigger.getAttribute('aria-expanded')==='true';trigger.setAttribute('aria-expanded',String(!open));menu.hidden=open;});
    document.addEventListener('click',e=>{if(wrap&&!wrap.contains(e.target)){menu.hidden=true;trigger.setAttribute('aria-expanded','false');}});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'){menu.hidden=true;trigger.setAttribute('aria-expanded','false');}});
  }
  if(menuToggle&&navLinks){menuToggle.addEventListener('click',()=>{const open=navLinks.classList.toggle('sth-open');menuToggle.setAttribute('aria-expanded',String(open));});}
  const current=location.pathname.split('/').pop().toLowerCase() || 'index.html';
  document.querySelectorAll('.sth-nav-links > a').forEach(a=>{if(a.getAttribute('href').toLowerCase()===current)a.setAttribute('aria-current','page');});
})();
