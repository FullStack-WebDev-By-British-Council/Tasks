const words = ["Notes", "Tools", "Practice", "Resources"];
let wordIndex = 0;
let charIndex = 0;
function typeWord(){const target=document.getElementById("typing-text");if(!target)return;const word=words[wordIndex];target.textContent=word.substring(0,charIndex);charIndex++;if(charIndex>word.length){setTimeout(deleteWord,1000);return;}setTimeout(typeWord,100);}
function deleteWord(){const target=document.getElementById("typing-text");if(!target)return;const word=words[wordIndex];target.textContent=word.substring(0,charIndex);charIndex--;if(charIndex<0){wordIndex=(wordIndex+1)%words.length;charIndex=0;setTimeout(typeWord,300);return;}setTimeout(deleteWord,60);}
typeWord();
