document.addEventListener('DOMContentLoaded',function(){
 const input=document.getElementById('srch');const button=document.getElementById('srchb');const message=document.getElementById('search-message');
 if(!input||!button)return;
 const box=input.closest('.search-box')||input.parentElement;let results=document.getElementById('sthSearchResults');
 if(!results){results=document.createElement('div');results.id='sthSearchResults';results.className='sth-search-results';results.setAttribute('role','listbox');box.appendChild(results);}
 const items=window.STUDY_SEARCH_ITEMS||[];
 const normalize=s=>String(s||'').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9\s&+-]/g,' ').replace(/\s+/g,' ').trim();
 function render(){const q=normalize(input.value);results.innerHTML='';if(message)message.textContent='';if(!q){results.classList.remove('is-visible');return;}
  const matches=items.map(item=>({...item,score:(normalize(item.title)===q?100:0)+(normalize(item.title).startsWith(q)?30:0)+(normalize(item.title).includes(q)?20:0)+(normalize(item.category).includes(q)?10:0)+(normalize(item.keywords).includes(q)?5:0)})).filter(item=>item.score>0||normalize(item.title).split(' ').some(w=>w.startsWith(q))).sort((a,b)=>b.score-a.score).filter((item,i,arr)=>arr.findIndex(x=>x.url===item.url)===i).slice(0,8);
  if(!matches.length){const empty=document.createElement('div');empty.className='sth-search-empty';empty.textContent='No matching tools or notes found.';results.appendChild(empty);results.classList.add('is-visible');return;}
  matches.forEach(item=>{const a=document.createElement('a');a.className='sth-search-result';a.href=item.url;a.setAttribute('role','option');const title=document.createElement('strong');title.textContent=item.title;const cat=document.createElement('span');cat.textContent=item.category;a.append(title,cat);results.appendChild(a);});results.classList.add('is-visible');
 }
 function submit(){const q=normalize(input.value);if(!q){if(message)message.textContent='Please enter a tool or topic.';input.focus();return;}const first=results.querySelector('a');if(first){window.location.href=first.href;}else{render();if(message)message.textContent='No matching tools or notes found.';}}
 input.addEventListener('input',render);input.addEventListener('focus',render);input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();submit();}if(e.key==='Escape')results.classList.remove('is-visible');});button.addEventListener('click',submit);document.addEventListener('click',e=>{if(!box.contains(e.target))results.classList.remove('is-visible');});
});
