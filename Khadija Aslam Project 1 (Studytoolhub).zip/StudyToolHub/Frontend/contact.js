const contactForm = document.getElementById("contactForm");
const name = document.getElementById("name");
const email = document.getElementById("email");
const subject = document.getElementById("subject");
const message = document.getElementById("message");

const nameError = document.getElementById("nameError");
const emailError = document.getElementById("emailError");
const subjectError = document.getElementById("subjectError");
const messageError = document.getElementById("messageError");

const successMessage = document.getElementById("successMessage");
const submitBtn = document.getElementById("submitBtn");

contactForm.addEventListener("submit", async function(event) {
    event.preventDefault();
let isValid = true;
    
// Name Validation
    if (name.value.trim().length < 3) {
        nameError.innerText = "Name must be at least 3 characters.";
        isValid = false;
    } else {
        nameError.innerText = "";}
    
        // Email Validation

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email.value.trim())) {
        emailError.innerText = "Please enter a valid email address.";
        isValid = false;
    } else {
        emailError.innerText = "";}

        // Subject Validation

        if (subject.value.trim().length < 3) {
        subjectError.innerText = "Subject must be at least 3 characters.";
        isValid = false;
    } else {
        subjectError.innerText = "";}

        // Message Validation

        if (message.value.trim().length < 10) {
        messageError.innerText = "Message must be at least 10 characters.";
        isValid = false;
    } else {
        messageError.innerText = "";}
    successMessage.innerText = "";
    
    // Stop if form is invalid

    if (!isValid) {
        return;}

    // Send data to backend
    submitBtn.disabled = true;
    submitBtn.innerText = "Sending...";
    try {
        const response = await fetch("http://localhost:5500/contact", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"},
            body: JSON.stringify({
                name: name.value.trim(),
                email: email.value.trim(),
                subject: subject.value.trim(),
                message: message.value.trim()
            })
         });
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.message || "Message could not be sent."); }
        successMessage.innerText =
            "Thank you for contacting us! Your message has been saved.";
        contactForm.reset();
    } catch (error) {
        successMessage.innerText =
            "Unable to send your message. Please try again.";
    console.log("Contact Form Error:", error.message);
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML =
        '<i class="ri-send-plane-fill"></i> Send Message';}});